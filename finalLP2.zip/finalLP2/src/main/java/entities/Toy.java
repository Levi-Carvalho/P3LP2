package entities;

import java.util.ArrayList;

public class Toy extends Attraction{
    private String opHours;
    private String price;
    private String minHeight;

    private ArrayList<String> dependencies;

    public Toy() {
        this.dependencies = new ArrayList<>();
    }


    public ArrayList<String> getDependencies() {
        return dependencies;
    }

    public void addDependencie(String depen) {
        this.dependencies.add(depen);
    }

    public void setOpHours(String opHours) {
        this.opHours = opHours;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setMinHeight(String minHeight) {
        this.minHeight = minHeight;
    }

    public String getOpHours() {
        return opHours;
    }

    public String getPrice() {
        return price;
    }

    public String getMinHeight() {
        return minHeight;
    }
}
