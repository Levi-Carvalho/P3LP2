package entities;

public interface Attractions {

}
