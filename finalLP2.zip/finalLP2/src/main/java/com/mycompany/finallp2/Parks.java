package com.mycompany.finallp2;

import entities.Attraction;
import entities.User;

import java.util.ArrayList;

public interface Parks {
    void makeAttPanels();
    void loadAttractions(String src);
    void saveUser(User user);
    void saveAttractions(ArrayList<Attraction> att);
}
