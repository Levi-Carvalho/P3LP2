package com.mycompany.finallp2;

import entities.Attraction;
import entities.Toy;
import entities.User;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.ArrayList;

public class Park extends javax.swing.JFrame implements Parks {
    protected User user;
    protected ArrayList<Attraction> attractions;
    protected ArrayList<JPanel> attPanels;

    public Park(User user) {
        this.user = user;
        this.attractions = new ArrayList<>();
        this.attPanels = new ArrayList<>();
        final Park park = this;
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                park.saveUser(park.user);
                park.saveAttractions(park.attractions);
            }
        });
    }

    public Park(){}
    public void loadAttractions(String src) {
        try (BufferedReader br = new BufferedReader(new FileReader(src))){
            String u = br.readLine();
            while(u != null) {
                String[] fields = u.split("///");
                if(fields[0].equals("brinquedo")) {
                    Toy attr = new Toy();
                    attr.setName(fields[1]);
                    attr.setPrice(fields[2]);
                    String opHours = fields[4];
                    String[] depend = fields[5].split(";");
                    for (String att: depend){
                        attr.addDependencie(att);
                    }
                    attr.setOpHours(opHours);
                    attr.setDescription(fields[6]);
                    attr.setMinHeight(fields[3]);

                    System.out.println("wesdssss");
                    this.attractions.add(attr);
                }
                System.out.println(u);
                u = br.readLine();
            }
            makeAttPanels();
        } catch (IOException e) {
            System.out.println("err parkadm $$$%@# " + e.getMessage());
        }
    }
    public void makeAttPanels() {
        for (Attraction a: this.attractions) {
            if(a instanceof Toy) {
                Toy toy = (Toy) a;

                JPanel attra = new CToy(toy, this.user, this);
                this.attPanels.add(attra);
            }
        }
    }

    public void saveUser(User user) {
        String str = "";
        String src = "/home/levi/NetBeansProjects/finalLP2/src/main/java/com/mycompany/finallp2/users.txt";
        String tempSrc = "/home/levi/NetBeansProjects/finalLP2/src/main/java/com/mycompany/finallp2/tempUsers.txt";
        str += user.getName() + ",";
        str += user.getPassword() + ",";
        for(int i = 0; i < this.user.getVisited().size(); i++) {
            if(i != 0)
                str += ";";
            str += this.user.getVisited().get(i);
        }
        str += ",";
        for(int i = 0; i < this.user.getTickets().size(); i++) {
            if(i != 0)
                str += ";";
            str += this.user.getTickets().get(i);
        }
        str += ",";
        str += user.getHeight();
        try (BufferedReader leitor = new BufferedReader(new FileReader(src));
             BufferedWriter escritor = new BufferedWriter(new FileWriter(tempSrc))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                if (linha.startsWith(this.user.getName())) {
                    escritor.write(str);
                    escritor.newLine();
                } else {
                    escritor.write(linha);
                    escritor.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            if (!new File(src).delete()) {
                throw new IOException("Falha ao excluir o arquivo original");
            }
            if (!new File(tempSrc).renameTo(new File(src))) {
                throw new IOException("Falha ao renomear o arquivo temporário");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveAttractions(ArrayList<Attraction> att) {

    }
}
