/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.finallp2;

import entities.User;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author levi
 */
public class FinalLP2 {

    public static void main(String[] args) {
        (new Login()).setVisible(true);
        System.out.println("Hello World!");
    }

    public static User login(String src, String username, String pass) {
        try (BufferedReader br = new BufferedReader(new FileReader(src))){
            String u = br.readLine();
            while(u != null) {
//                System.out.println(u);
                String[] fields = u.split(",");

                if(fields[0].equals(username) && fields[1].equals(pass)) {

                    User user = new User();

                    user.setName(fields[0]);
                    user.setHeight(fields[4]);
                    user.setPassword(fields[1]);
                    String[] visits = fields[2].split(";");
                    String[] tickets = fields[3].split(";");

                    for (String v: visits)
                        user.addVisit(v);
                    for (String t : tickets)
                        user.addTicket(t);
                    System.out.println("weeeeeeeeeeeee");
                    return user;
                }
                u = br.readLine();
            }
        } catch (IOException e) {
            System.out.println("err das" + e.getMessage());
        }
        return null;
    }
}
