package p3_lp2.entities;

public class Lanche {
    private String name;
    private String price;

    public Lanche(String n, String p) {
        this.setName(n);
        this.setPrice(p);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
