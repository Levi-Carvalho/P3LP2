package p3_lp2.entities;

import p3_lp2.components.CAnimal;
import p3_lp2.components.CLanchonete;
import p3_lp2.components.CToy;
import p3_lp2.entities.attraction.Attraction;
import p3_lp2.entities.attraction.Lanchonete;
import p3_lp2.entities.attraction.Toy;
import p3_lp2.entities.attraction.Animal;
import p3_lp2.imcomming.ParkAdm;
import p3_lp2.imcomming.Parks;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.ArrayList;

import static p3_lp2.imcomming.Main.concatenateArray;
import static p3_lp2.imcomming.Main.resourcePath;

public class Park extends javax.swing.JFrame implements Parks {
    protected User user;
    protected ArrayList<Attraction> attractions;
    protected ArrayList<JPanel> attPanels;

    public Park(User user) {
        this.user = user;
        this.attractions = new ArrayList<>();
        this.attPanels = new ArrayList<>();
        final Park park = this;
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                park.saveUser(park.user);
                park.saveAttractions(park.attractions);
            }
        });
    }

    public Park(){}

    private Toy toyPanel(String[] fields) {
        Toy toy = new Toy();
        toy.setName(fields[1]);
        toy.setPrice(fields[2]);
        String opHours = fields[4];
        String[] depend = fields[5].split(";");
        for (String att: depend){
            toy.addDependencie(att);
        }
        toy.setOpHours(opHours);
        toy.setDescription(fields[6]);
        toy.setMinHeight(fields[3]);

        return toy;
    }

    private Animal animalPanel(String[] fields) {
        Animal a= new Animal();
        a.setType(fields[0]);
        a.setName(fields[1]);
        a.setDescription(fields[2]);
        return a;
    }
    private Lanchonete LanchonetePanel(String[] fields) {
        Lanchonete lanchonete = new Lanchonete();
        Lanche lanche;
        lanchonete.setName(fields[1]);
        lanchonete.setDescription(fields[2]);
        if (fields.length > 2) {
            for (String str : fields[3].split(";")) {
                String[] namePrice = str.split(",");
                lanche = new Lanche(namePrice[0], namePrice[1]);
                lanchonete.addLanche(lanche);

            }
        }
        return lanchonete;
    }
    public void loadAttractions(String src) {
        try (BufferedReader br = new BufferedReader(new FileReader(src))){
            String u = br.readLine();
            while(u != null) {
                String[] fields = u.split(">r<");
                if(fields[0].equals("brinquedo")) {
                    attractions.add(toyPanel(fields));

                } else if (fields[0].equals("animal")) {
                    attractions.add(animalPanel(fields));

                } else if(fields[0].equals("lanchonete")) {
                    attractions.add(LanchonetePanel(fields));

                }
                System.out.println(u);
                u = br.readLine();
            }
            makeAttPanels();
        } catch (IOException e) {
            System.out.println("err parkadm $$$%@# " + e.getMessage());
        }
    }
    public void makeAttPanels() {
        for (Attraction a: this.attractions) {
            if(a instanceof Toy) {
                Toy toy = (Toy) a;
                JPanel toyPanel = new CToy(toy, this.user, this);
                this.attPanels.add(toyPanel);
            } else if (a instanceof Animal) {
                Animal animal = (Animal) a;
                JPanel animalPanel = new CAnimal(animal, this);
                this.attPanels.add(animalPanel);
            } else if (a instanceof Lanchonete) {
                Lanchonete lanchonete = (Lanchonete) a;
                JPanel lanchonetePanel = new CLanchonete(lanchonete, this);
                this.attPanels.add(lanchonetePanel);
            }
        }
    }

    public void saveUser(User user) {
        String str = "";
        String src = resourcePath("users.txt");
        String tempSrc = resourcePath("tempUsers.txt");
        str += user.getName() + ",";
        str += user.getPassword() + ",";
        str += concatenateArray(user.getVisited()) + ",";
        str += concatenateArray(user.getTickets()) + ",";
        str += user.getHeight();

        try (BufferedReader leitor = new BufferedReader(new FileReader(src));
             BufferedWriter escritor = new BufferedWriter(new FileWriter(tempSrc))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                if (linha.startsWith(user.getName())) {
                    escritor.write(str);
                    escritor.newLine();
                } else {
                    escritor.write(linha);
                    escritor.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            if (!new File(src).delete()) {
                throw new IOException("Falha ao excluir o arquivo original");
            }
            if (!new File(tempSrc).renameTo(new File(src))) {
                throw new IOException("Falha ao renomear o arquivo temporário");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveAttractions(ArrayList<Attraction> attraction) {
        String str = "";
        String src = resourcePath("attractions.txt");
        String tempSrc = resourcePath("tempAttraction.txt");

        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(tempSrc))) {
            for (Attraction att : attraction) {
                if(att instanceof Toy) {
                    Toy toy = (Toy) att;
                    str = toy.toString();
                } else if (att instanceof Animal) {
                    Animal animal = (Animal) att;
                    str = animal.toString();
                } else if (att instanceof Lanchonete) {
                    Lanchonete lanchonete = (Lanchonete) att;
                    str = lanchonete.toString();
                }

                escritor.write(str);
                System.out.println("asdas");
                escritor.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            if (!new File(src).delete()) {
                throw new IOException("Falha ao excluir o arquivo original");
            }
            if (!new File(tempSrc).renameTo(new File(src))) {
                throw new IOException("Falha ao renomear o arquivo temporário");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Attraction> getAttractions() {
        return attractions;
    }
    public void removeAttraction(int index) {
        this.attractions.remove(index);
    }

    public void addAttraction(Attraction a) {
        this.attractions.add(a);
    }

    public User getUser() {
        return user;
    }

    public static void btnRemoveClicked(JPanel panel, Park park, Attraction attr) {
        if(park instanceof ParkAdm) {
            int sure = JOptionPane.showConfirmDialog(panel, "Remover " + attr.getName() + "?");
            if(sure == 0) {
                ((ParkAdm) park).removeAtrraction(panel);
                ArrayList<Attraction> attrs = park.getAttractions();
                for (int i = 0; i < attrs.size(); i++) {
                    String att = attrs.get(i).getName();
                    if(att.equals(attr.getName())) {
                        park.removeAttraction(i);
                        return;
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(panel, "você não tem permissão");
        }
    }

}
