package p3_lp2.entities;

import java.util.ArrayList;

public class User {
    private String name;
    private String money;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    private String password;
    private String height;

    private ArrayList<String> visited;
    private ArrayList<String> tickets;


    public void setHeight(String height) {
        this.height = height;
    }

    public String getHeight() {
        return height;
    }

    public User(){
        this.money = "3000";
        this.visited = new ArrayList<String>();
        this.tickets = new ArrayList<String>();
    }

    public User(String [] fields) {
        this.money = "2000";
        this.visited = new ArrayList<String>();
        this.tickets = new ArrayList<String>();

        this.setName(fields[0]);
        this.setHeight(fields[4]);
        this.setPassword(fields[1]);

        String[] visits = fields[2].split(";");
        String[] tickets = fields[3].split(";");

        for (String v: visits)
            this.addVisit(v);
        for (String t : tickets)
            this.addTicket(t);
    }


    public void setName(String name) {
        this.name = name;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public void addVisit(String atc) {
        this.visited.add(atc);
    }

    public String getName() {
        return name;
    }

    public String getMoney() {
        return money;
    }


    public ArrayList<String> getVisited() {
        return visited;
    }
    public boolean BuyTicket(int price, String ticket) {
        int m = Integer.parseInt(this.money);
        if(m > price) {
            m -= price;
            this.money = String.valueOf(m);
            this.tickets.add(ticket);
            return true;
        }
        return false;
    }

    public boolean BuyLanche(int price) {
        int m = Integer.parseInt(this.money);
        if(m > price) {
            m -= price;
            this.money = String.valueOf(m);
            return true;
        }
        return false;
    }

    public void addTicket(String ticket) {
        this.tickets.add(ticket);
    }
    public void removeTicket(int index) {
        this.tickets.remove(index);
    }

    public ArrayList<String> getTickets() {
        return tickets;
    }
}
