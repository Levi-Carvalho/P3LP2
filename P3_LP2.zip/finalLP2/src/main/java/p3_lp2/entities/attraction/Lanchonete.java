package p3_lp2.entities.attraction;

import p3_lp2.entities.Lanche;

import java.util.ArrayList;

public class Lanchonete extends Attraction {
    private ArrayList<Lanche> lanches;

    public Lanchonete() {
        super();
        this.lanches = new ArrayList<>();
    }

    @Override
    public String toString() {
        Lanche lanche;
        String str = "lanchonete>r<";
        str += this.getName() + ">r<";
        str += this.getDescription() + ">r<";
        for (int i = 0; i < this.getLanches().size(); i++) {
            if(i != 0)
                str += ";";
            lanche = this.getLanches().get(i);
            str += lanche.getName()+ ",";
            str += lanche.getPrice();
        }
        return str;
    }

    public void addLanche(Lanche lanche) {
        lanches.add(lanche);
    }

    public ArrayList<Lanche> getLanches() {
        return lanches;
    }
}
