package p3_lp2.entities.attraction;


public class Animal extends Attraction {
    public Animal(){
        this.setType("animal");
    }

    @Override
    public String toString() {
        String str = "animal>r<";
        str += this.getName() + ">r<";
        str += this.getDescription();
        return str;
    }
}
