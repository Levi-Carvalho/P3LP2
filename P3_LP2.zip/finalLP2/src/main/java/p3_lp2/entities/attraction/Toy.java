package p3_lp2.entities.attraction;

import java.util.ArrayList;

public class Toy extends Attraction {
    private String opHours;
    private String price;
    private String minHeight;

    private ArrayList<String> dependencies;

    public Toy() {
        this.dependencies = new ArrayList<>();
    }

    @Override
    public String toString() {
        String str = "brinquedo>r<";
        str += this.getName() + ">r<";
        str += this.getPrice() + ">r<";
        str += this.getMinHeight() + ">r<";
        str += this.getOpHours() + ">r<";
        for(int i = 0; i < this.getDependencies().size(); i++) {
            if(i != 0)
                str += ";";
            str += this.getDependencies().get(i);
        }
        str += ">r<" + this.getDescription();
        return str;
    }

    public ArrayList<String> getDependencies() {
        return dependencies;
    }

    public void addDependencie(String depen) {
        this.dependencies.add(depen);
    }

    public void setOpHours(String opHours) {
        this.opHours = opHours;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setMinHeight(String minHeight) {
        this.minHeight = minHeight;
    }

    public String getOpHours() {
        return opHours;
    }

    public String getPrice() {
        return price;
    }

    public String getMinHeight() {
        return minHeight;
    }
}
