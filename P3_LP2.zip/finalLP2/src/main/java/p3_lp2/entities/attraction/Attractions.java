package p3_lp2.entities.attraction;

public interface Attractions {

}
