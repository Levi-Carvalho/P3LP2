package p3_lp2.imcomming;

import p3_lp2.entities.User;
import p3_lp2.entities.attraction.Attraction;

import java.util.ArrayList;

public interface Parks {
    void makeAttPanels();
    void loadAttractions(String src);
    void saveUser(User user);
    void saveAttractions(ArrayList<Attraction> att);
}
