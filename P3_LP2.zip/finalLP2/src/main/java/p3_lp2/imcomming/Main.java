/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package p3_lp2.imcomming;

import p3_lp2.entities.User;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 *
 * @author levi
 */
public class Main {

    public static void main(String[] args) {
        (new Login()).setVisible(true);
    }

    public static String resourcePath(String resource) {
        Path path = Paths.get(System.getProperty("user.dir"));
        path = path.resolve("src");
        path = path.resolve("main");
        path = path.resolve("java");
        path = path.resolve("p3_lp2");
        path = path.resolve("resources");
        path = path.resolve(resource);

        return path.toString();
    }

    public static User login(String src, String username, String pass) {
        try (BufferedReader br = new BufferedReader(new FileReader(src))){
            String u = br.readLine();
            while(u != null) {
                String[] fields = u.split(",");
                if(fields[0].equals(username) && fields[1].equals(pass)) {
                    return  new User(fields);
                }
                u = br.readLine();
            }
        } catch (IOException e) {
            System.out.println("err das " + e.getMessage());
        }
        return null;
    }

    public static String concatenate(ArrayList<String> arr, String j) {
        String str = "";
        for(String t : arr) {
            str += t + ", ";
        }
        return str;
    }

    public static String concatenateArray(ArrayList<String> arr) {
        String str = "";
        for(int i = 0; i < arr.size(); i++) {
            if(i != 0)
                str += ";";
            str += arr.get(i);
        }
        return str;
    }
}
